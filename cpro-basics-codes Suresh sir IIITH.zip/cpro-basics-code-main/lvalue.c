#include <stdio.h>

main()
{
    int i = 1;
    12 = i + 1;
}