#include <stdio.h>

int main()
{
    char c = 'A';
   
    printf("%c -- %d\n", c, c);

}