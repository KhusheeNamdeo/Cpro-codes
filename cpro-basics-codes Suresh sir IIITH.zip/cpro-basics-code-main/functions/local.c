#include <stdio.h>

main()
{
    int a;

    printf("Address of a: %u\n", &a);
}