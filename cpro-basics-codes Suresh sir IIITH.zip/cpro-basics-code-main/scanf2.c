#include <stdio.h>

main()
{
	int i, j;
	
	scanf("%d/%d", &i, &j);

    printf("i/j = %d/%d\n", i, j);
}