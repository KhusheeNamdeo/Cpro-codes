#include <stdio.h>

int main(void)
{
  char *str1 = "Hello World\n";
  char *str2 = "Hello World Again\n";
 // printf("1--> %s", str1);
  printf(str1);
  puts(str1);
  return 0;
}
