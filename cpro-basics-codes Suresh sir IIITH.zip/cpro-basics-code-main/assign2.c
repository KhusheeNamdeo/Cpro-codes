#include <stdio.h>

main()
{

    int i;
    float f;

    f = i = 33.3f;

    printf("i = %d f = %f\n", i, f);
}
