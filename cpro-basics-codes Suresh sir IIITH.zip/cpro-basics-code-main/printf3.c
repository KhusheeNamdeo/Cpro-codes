#include <stdio.h>

int main()
{
    int i;
    float x;
    
    i = 9;
    x = 43.2892f;
    
    printf("i = %f\n", i);
    printf("x = %d\n", x);

}