#include <stdio.h>

main()
{
    int a = 1, b = 2, c = 3;
    
    printf("%d\n", a-b-c);
}