#include <stdio.h>

main()
{
    printf("\\ \n");
}