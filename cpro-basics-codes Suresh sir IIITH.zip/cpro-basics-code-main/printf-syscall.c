#include <stdio.h>

main()
{
    int n;
    printf("Hello-1");
    scanf("%d", &n);
    printf("Hello-2\n");
    printf("Hello-3");
}