main()
{
    while(1);
}