#include <stdio.h>

main()
{
    int n1, n2;

    scanf("%d", &n1);
    scanf("%d", &n2);
}