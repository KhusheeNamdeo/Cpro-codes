#include <stdio.h>

int main()
{
    int i, j;
    float x, y;
    
    i = 10;
 
    printf("%d %d\n", i);
    printf("%d\n", i, i);
}