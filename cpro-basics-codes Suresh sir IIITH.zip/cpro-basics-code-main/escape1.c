#include <stdio.h>

main()
{
    printf("Item\tUnit\tPurchase\n\tPrice\tDate\n");
}